# Regular Expressions with Special Characters

## Instructions

* Load in the "Alice in Wonderland" text into a DataFrame `alice_df`.

* Create a regular expression to find all lines that start with the string `Alice`.

* Create a regular expression to find all lines that end with an exclamation mark (!).

* Create a regular expression to find all lines that end with an exclamation mark (!) or question mark (?).

---

© 2022 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.